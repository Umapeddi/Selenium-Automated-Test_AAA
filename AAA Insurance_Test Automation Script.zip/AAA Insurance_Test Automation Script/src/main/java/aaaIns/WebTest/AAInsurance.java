package aaaIns.WebTest;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AAInsurance {

static WebDriver driver;
	
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver","C://Software//chromedriver//chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.aaalife.com/term-life-insurance-quote-input");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebElement zip = driver.findElement(By.xpath("//*[@id='zip']"));
		zip.click();
		zip.clear();
		zip.sendKeys("48202");

		Select gender = new Select(driver.findElement(By.id("gender")));
		gender.selectByVisibleText("Male");
		
		Select month = new Select(driver.findElement(By.id("month")));
		month.selectByVisibleText("March");
		
		Select day = new Select(driver.findElement(By.id("day")));
		day.selectByValue("5");
		
		Select year = new Select(driver.findElement(By.id("year")));
		year.selectByValue("1995");
		
		WebElement radioMember = driver.findElement(By.id("isMemberNo"));
		radioMember.click();
		
		WebElement email = driver.findElement(By.id("contact_email"));
		email.sendKeys("abc@gmail.com");
		
		Select height = new Select(driver.findElement(By.id("feet")));
		height.selectByValue("5");
		
		Select inches = new Select(driver.findElement(By.id("inches")));
		inches.selectByValue("0");
		
		WebElement weight = driver.findElement(By.id("weight"));
		weight.click();
		weight.sendKeys("130");
		
		WebElement radioNicotineUse = driver.findElement(By.id("nicotineUseNo"));
		radioNicotineUse.click();
		
//		WebDriverWait wait = new WebDriverWait(driver, 10);
//		WebElement rateYourHealth = wait
//				.until(ExpectedConditions.visibilityOfElementLocated(By.id("rateYourHealth")));
		
		Select rateYourHealth = new Select(driver.findElement(By.id("rateYourHealth")));
		
		rateYourHealth.selectByVisibleText("Excellent");
		
		Select coverageAmount = new Select(driver.findElement(By.id("coverageAmount")));
		coverageAmount.selectByValue("550,000");
		
		Select termLength = new Select(driver.findElement(By.id("termLength")));
		termLength.selectByValue("10");
		
		WebElement seeQuote = driver.findElement(By.id("seeQuote"));
		seeQuote.click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebElement applyNow = driver.findElement(By.id("quoteResultsApplyNow"));
		if(applyNow.isDisplayed()){
			
			System.out.println("You are on results page");
		}
		
	}

}
